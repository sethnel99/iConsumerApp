//
//  ThinUITableViewCell.h
//  NomadClient
//
//  Created by Farley User on 2/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThinUITableViewCell : UITableViewCell

@end
